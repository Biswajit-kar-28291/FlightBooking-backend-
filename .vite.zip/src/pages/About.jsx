// src/pages/About.jsx
function About() {
  return (
    <div className="container-sm my-5">
      <div className="bg-body-secondary p-4 rounded">
        <div class="card my-3">
  <div class="card-header">
    ABCD
  </div>
  <div class="card-body">
    <figure>
      <blockquote class="blockquote">
        <p>A well-known quote, contained in a blockquote element. Lorem ipsum dolor sit amet consectetur.</p>
      </blockquote>
      <figcaption class="blockquote-footer">
        Someone famous in <cite title="Source Title">Source Title</cite>
      </figcaption>
    </figure>
  </div>
</div>
        <div class="card my-3">
  <div class="card-header">
    ABCD
  </div>
  <div class="card-body">
    <figure>
      <blockquote class="blockquote">
        <p>A well-known quote, contained in a blockquote element. Lorem ipsum dolor, sit amet consectetur adipisicing elit. Cum, sint.</p>
      </blockquote>
      <figcaption class="blockquote-footer">
        Someone famous in <cite title="Source Title">Source Title</cite>
      </figcaption>
    </figure>
  </div>
</div>
        <div class="card my-3">
  <div class="card-header">
   XYZ
  </div>
  <div class="card-body">
    <figure>
      <blockquote class="blockquote">
        <p>A well-known quote, contained in a blockquote element.</p>
      </blockquote>
      <figcaption class="blockquote-footer">
        Someone famous in <cite title="Source Title">Source Title</cite>
      </figcaption>
    </figure>
  </div>
</div>
        <div class="card my-3">
  <div class="card-header">
    1234
  </div>
  <div class="card-body">
    <figure>
      <blockquote class="blockquote">
        <p>A well-known quote, contained in a blockquote element. Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ratione eius modi maxime officia placeat facere quasi numquam assumenda reprehenderit aliquid?</p>
      </blockquote>
      <figcaption class="blockquote-footer">
        Someone famous in <cite title="Source Title">Source Title</cite>
      </figcaption>
    </figure>
  </div>
</div>
      </div>
    </div>
  );
}
export default About;
