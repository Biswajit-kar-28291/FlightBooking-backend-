import { useNavigate,Link } from "react-router-dom";

export default function Login() {
  const navigate = useNavigate();

  const handleLogin = () => {
    navigate("/");
  };

  return (
    <div className="container d-flex justify-content-center align-items-center min-vh-100">
  <div className="card shadow p-4 my-5" style={{ width: "450px" }}>
    <h3 className="text-center mb-4">Register</h3>

    {/* First Name */}
    <div className="mb-3">
      <label className="form-label">First Name</label>
      <input type="text" className="form-control" placeholder="Enter first name" />
    </div>

    {/* Last Name */}
    <div className="mb-3">
      <label className="form-label">Last Name</label>
      <input type="text" className="form-control" placeholder="Enter last name" />
    </div>

    {/* Age */}
    <div className="mb-3">
      <label className="form-label">Age</label>
      <input type="number" className="form-control" placeholder="Enter age" />
    </div>

    {/* Gender */}
    <div className="mb-3">
      <label className="form-label">Gender</label>
      <select className="form-select">
        <option value="">Select gender</option>
        <option>Male</option>
        <option>Female</option>
        <option>Other</option>
      </select>
    </div>

    {/* Phone */}
    <div className="mb-3">
      <label className="form-label">Phone Number</label>
      <input type="tel" className="form-control" placeholder="Enter phone number" />
    </div>

    {/* Email */}
    <div className="mb-3">
      <label className="form-label">Email Address</label>
      <input type="email" className="form-control" placeholder="Enter email" />
    </div>

    {/* Address */}
    <div className="mb-3">
      <label className="form-label">Address</label>
      <textarea
        className="form-control"
        rows="2"
        placeholder="Enter address"
      ></textarea>
    </div>

    {/* Aadhaar */}
    <div className="mb-3">
      <label className="form-label">Aadhaar Number</label>
      <input type="text" className="form-control" placeholder="Enter Aadhaar number" />
    </div>

    {/* Password */}
    <div className="mb-3">
      <label className="form-label">Password</label>
      <input type="password" className="form-control" placeholder="Create password" />
    </div>

    <button className="btn btn-primary w-100" onClick={handleLogin}>Register</button>

    <p className="text-center mt-3 mb-0">
      Already have an account? <Link to="/">Login</Link>
    </p>
  </div>
</div>

  );
}
