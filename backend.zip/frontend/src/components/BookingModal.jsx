import { useState } from "react";

function BookingModal({ onSearch }) {
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [date, setDate] = useState("");

  const handleSearch = () => {
    onSearch({ from, to, date });

    // Close modal manually
    document.getElementById("closeBooking").click();
  };

  return (
    <div className="modal fade" id="bookingModal" tabIndex="-1">
      <div className="modal-dialog modal-dialog-centered">
        <div className="modal-content">
          <div className="modal-header">
            <h5 className="modal-title">Flight Search</h5>
            <button
              id="closeBooking"
              className="btn-close"
              data-bs-dismiss="modal"
            ></button>
          </div>

          <div className="modal-body">
            <input className="form-control mb-2" placeholder="From"
              onChange={(e) => setFrom(e.target.value)} />

            <input className="form-control mb-2" placeholder="To"
              onChange={(e) => setTo(e.target.value)} />

            <input type="date" className="form-control"
              onChange={(e) => setDate(e.target.value)} />
          </div>

          <div className="modal-footer">
            <button className="btn btn-primary" onClick={handleSearch}>
              Search Flights
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default BookingModal;
