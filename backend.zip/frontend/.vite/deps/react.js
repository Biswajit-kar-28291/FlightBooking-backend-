import {
  require_react
} from "./chunk-6VPNIYGA.js";
import "./chunk-5WRI5ZAA.js";
export default require_react();
