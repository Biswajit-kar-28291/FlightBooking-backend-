
function login(){
    return(
        <>
        <button type="button" class="btn btn-primary">Primary</button>
        </>

    );
}
export default login;