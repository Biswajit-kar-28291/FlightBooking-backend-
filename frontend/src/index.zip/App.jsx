import { Routes, Route } from "react-router-dom";
import LoginLayout from "./layouts/LoginLayout.jsx";
import MainLayout from "./layouts/MainLayout.jsx";
import Home from "./pages/Home.jsx";
import About from "./pages/About.jsx";
import Contact from "./pages/Contact.jsx";
import Login from "./pages/login.jsx";
// import LoginLayout from "./layouts/LoginLayout.jsx";

function App() {
  return (
    <>
      <Routes>
        <Route element={<LoginLayout/>}>
          <Route path="/" element={<Login />} />
        </Route>

         <Route element={<MainLayout/>}>
          <Route path="/Home" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          </Route>
      </Routes>
    </>
  );
}

export default App;
